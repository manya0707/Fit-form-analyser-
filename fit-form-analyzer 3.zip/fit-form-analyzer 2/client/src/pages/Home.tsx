import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Activity,
  ArrowDownRight,
  ArrowUpRight,
  BadgeCheck,
  Bell,
  BookOpen,
  Camera,
  ChevronDown,
  CircleHelp,
  CirclePause,
  Clock3,
  Dumbbell,
  Gauge,
  Home as HomeIcon,
  Info,
  Layers3,
  Lightbulb,
  ListChecks,
  LockKeyhole,
  Menu,
  MoreHorizontal,
  Play,
  RotateCcw,
  ScanLine,
  Settings2,
  ShieldCheck,
  Sparkles,
  Target,
  TrendingUp,
  Video,
  X,
  Zap,
} from "lucide-react";
import { toast } from "sonner";

type NavItem = {
  label: string;
  icon: typeof Activity;
  badge?: string;
};

type AngleStatus = "good" | "watch";

type JointMetric = {
  label: string;
  value: string;
  detail: string;
  status: AngleStatus;
};

const navItems: NavItem[] = [
  { label: "Live analysis", icon: ScanLine },
  { label: "Session history", icon: Clock3, badge: "3" },
  { label: "Exercise library", icon: Dumbbell },
];

const exercises = [
  { name: "Bodyweight squat", category: "Lower body", cue: "Keep your knees tracking over your second toe.", target: "90° knee bend", muscle: "Quads + glutes", joints: "Knees · hips · ankles", benefits: "Builds leg strength, hip mobility, and everyday movement control." },
  { name: "Push-up", category: "Upper body", cue: "Keep one long line from shoulders to heels.", target: "45° elbow path", muscle: "Chest + triceps", joints: "Wrists · elbows · shoulders", benefits: "Builds pressing strength through the chest, shoulders, triceps, and core." },
  { name: "Reverse lunge", category: "Lower body", cue: "Drop your back knee straight down, not forward.", target: "90° front knee", muscle: "Glutes + hamstrings", joints: "Front knee · hips · ankles", benefits: "Improves single-leg balance, hip stability, and lower-body strength." },
  { name: "Plank", category: "Core", cue: "Brace your core and gently tuck your ribs.", target: "Neutral spine", muscle: "Core + shoulders", joints: "Shoulders · hips · spine", benefits: "Trains trunk stability and helps you maintain a strong neutral spine." },
  { name: "Jumping jack", category: "Cardio", cue: "Land softly with your knees relaxed and chest lifted.", target: "Soft landing", muscle: "Calves + shoulders", joints: "Knees · ankles · shoulders", benefits: "Raises heart rate, warms the whole body, and improves coordination." },
  { name: "Standing shoulder press", category: "Upper body", cue: "Keep your ribs stacked over your hips as you press.", target: "Stacked spine", muscle: "Shoulders + core", joints: "Shoulders · elbows · spine", benefits: "Builds overhead strength while teaching shoulder and trunk control." },
  { name: "Glute bridge", category: "Posterior chain", cue: "Squeeze at the top without arching your lower back.", target: "Full hip lockout", muscle: "Glutes + hamstrings", joints: "Hips · knees · spine", benefits: "Activates the glutes and posterior chain for stronger hip extension." },
  { name: "Mountain climber", category: "Core + cardio", cue: "Keep your shoulders over your wrists and move with control.", target: "Stable plank", muscle: "Core + hip flexors", joints: "Wrists · hips · knees", benefits: "Combines core endurance, hip mobility, and a low-equipment cardio challenge." },
];

const dietaryPlan = [
  { meal: "Breakfast", timing: "Start steady", suggestion: "Greek yogurt or eggs, oats or whole-grain toast, and one fruit.", purpose: "Protein + slow energy" },
  { meal: "Lunch", timing: "Midday fuel", suggestion: "Rice, potatoes, or roti with dal, chicken, fish, tofu, or beans plus vegetables.", purpose: "Balanced training fuel" },
  { meal: "Snack", timing: "Around training", suggestion: "Banana with yogurt, milk, or a small handful of nuts.", purpose: "Simple pre/post-session energy" },
  { meal: "Dinner", timing: "Recover well", suggestion: "A palm-sized protein serving, vegetables, and a comfortable portion of carbohydrates.", purpose: "Recovery + fullness" },
];

const BLOCK_SECONDS = 120;

const sessionPlan = [
  { minute: "00–02", name: "Bodyweight squat", exercise: 0, focus: "Warm-up + legs" },
  { minute: "02–04", name: "Reverse lunge", exercise: 2, focus: "Single-leg strength" },
  { minute: "04–06", name: "Push-up", exercise: 1, focus: "Upper-body push" },
  { minute: "06–08", name: "Glute bridge", exercise: 6, focus: "Posterior chain" },
  { minute: "08–10", name: "Standing shoulder press", exercise: 5, focus: "Shoulder stability" },
  { minute: "10–12", name: "Mountain climber", exercise: 7, focus: "Core finisher" },
];

function StatusPill({ children, tone = "lime" }: { children: React.ReactNode; tone?: "lime" | "amber" | "slate" }) {
  const toneClasses = {
    lime: "border-lime/20 bg-lime/10 text-lime",
    amber: "border-amber/20 bg-amber/10 text-amber-strong",
    slate: "border-white/10 bg-white/[0.06] text-white/60",
  };
  return <span className={`status-pill ${toneClasses[tone]}`}>{children}</span>;
}

function MetricCard({ label, value, detail, tone = "lime", icon: Icon }: { label: string; value: string; detail: string; tone?: "lime" | "amber" | "slate"; icon: typeof Activity }) {
  return (
    <div className="metric-card">
      <div className="metric-icon"><Icon size={16} strokeWidth={1.8} /></div>
      <p className="eyebrow">{label}</p>
      <div className={`metric-value ${tone === "amber" ? "text-amber" : tone === "slate" ? "text-white" : "text-lime"}`}>{value}</div>
      <p className="metric-detail">{detail}</p>
    </div>
  );
}

function JointChip({ joint, x, y, active = true }: { joint: string; x: number; y: number; active?: boolean }) {
  return (
    <div className={`joint-chip ${active ? "joint-chip-active" : ""}`} style={{ left: `${x}%`, top: `${y}%` }}>
      <span className="joint-dot" />
      <span>{joint}</span>
    </div>
  );
}

function PostureOverlay({ phase, isGood, exerciseIndex }: { phase: number; isGood: boolean; exerciseIndex: number }) {
  const sway = Math.sin(phase / 10) * 1.4;
  const bend = isGood ? Math.sin(phase / 13) * 1.8 : 5 + Math.sin(phase / 8) * 3;
  const accent = isGood ? "#b7f34a" : "#f0b95a";
  const lineProps = { fill: "none", stroke: accent, strokeLinecap: "round" as const, strokeLinejoin: "round" as const, filter: "url(#glow)" };
  const pose = (() => {
    if (exerciseIndex === 1 || exerciseIndex === 3 || exerciseIndex === 7) {
      const mountain = exerciseIndex === 7;
      return <g {...lineProps} strokeWidth="4"><path d={mountain ? "M92 312 L196 274 L300 313" : "M92 303 L246 240 L405 303"} /><path d={mountain ? "M196 274 L232 340 L287 275" : "M246 240 L285 325 M246 240 L200 323"} /><path d={mountain ? "M92 312 L58 360 M300 313 L341 360" : "M92 303 L58 355 M405 303 L439 355"} /><path d="M246 240 L246 184" /><circle cx="246" cy="162" r="22" fill={accent} />{mountain && <><path d="M232 340 L194 385 M287 275 L332 332" /><circle cx="232" cy="340" r="6" fill={accent} /><circle cx="287" cy="275" r="6" fill={accent} /></>}</g>;
    }
    if (exerciseIndex === 6) {
      return <g {...lineProps} strokeWidth="4"><path d="M72 334 L158 334 L254 292 L352 292" /><path d="M158 334 L208 376 M254 292 L305 351" /><path d="M352 292 L420 292" /><circle cx="403" cy="267" r="22" fill={accent} /><circle cx="158" cy="334" r="7" fill={accent} /><circle cx="254" cy="292" r="7" fill={accent} /><circle cx="352" cy="292" r="7" fill={accent} /></g>;
    }
    if (exerciseIndex === 4) {
      return <g {...lineProps} strokeWidth="4"><path d="M246 126 L246 260" /><path d="M246 164 L120 82 M246 164 L372 82" /><path d="M246 260 L130 380 M246 260 L362 380" /><path d="M120 82 L72 44 M372 82 L420 44 M130 380 L72 450 M362 380 L420 450" /><circle cx="246" cy="93" r="23" fill={accent} /><circle cx="246" cy="164" r="7" fill={accent} /><circle cx="246" cy="260" r="7" fill={accent} /></g>;
    }
    if (exerciseIndex === 2) {
      return <g {...lineProps} strokeWidth="4"><path d={`M246 88 L246 176 L${184 - bend} 258 L148 375`} /><path d={`M246 176 L${310 + bend} 255 L${366 + bend} 365`} /><path d="M246 176 L170 236 L106 274 M246 176 L321 228 L382 254" /><path d="M148 375 L98 438 M366 365 L424 425" /><circle cx="246" cy="54" r="22" fill={accent} /><circle cx="246" cy="176" r="7" fill={accent} /><circle cx={184 - bend} cy="258" r="7" fill={accent} /><circle cx={310 + bend} cy="255" r="7" fill={accent} /></g>;
    }
    if (exerciseIndex === 5) {
      return <g {...lineProps} strokeWidth="4"><path d="M246 105 L246 274" /><path d="M246 150 L167 74 L167 26 M246 150 L325 74 L325 26" /><path d="M246 274 L207 432 M246 274 L285 432" /><path d="M207 432 L180 486 M285 432 L312 486" /><circle cx="246" cy="70" r="22" fill={accent} /><circle cx="246" cy="150" r="7" fill={accent} /><circle cx="167" cy="74" r="7" fill={accent} /><circle cx="325" cy="74" r="7" fill={accent} /></g>;
    }
    return <g {...lineProps} strokeWidth="4"><path d={`M${249 + sway} 88 L${246 + sway} 151 L${217 + sway} 224 L${183 + sway - bend} 315 L${171 + sway - bend} 414`} /><path d={`M${249 + sway} 88 L${256 + sway} 150 L${287 + sway} 225 L${321 + sway + bend} 315 L${329 + sway + bend} 414`} /><path d={`M${246 + sway} 151 L${204 + sway} 220 L${173 + sway - bend} 292 M${256 + sway} 150 L${300 + sway} 216 L${327 + sway + bend} 290`} /><path d={`M${148 + sway - bend} 420 L${124 + sway - bend} 485 M${358 + sway + bend} 420 L${384 + sway + bend} 485`} /><circle cx={249 + sway} cy="55" r="22" fill={accent} /><circle cx={246 + sway} cy="151" r="7" fill={accent} /><circle cx={256 + sway} cy="150" r="7" fill={accent} /><circle cx={173 + sway - bend} cy="292" r="7" fill={accent} /><circle cx={327 + sway + bend} cy="290" r="7" fill={accent} /></g>;
  })();
  return (
    <svg className="pose-overlay" viewBox="0 0 500 520" aria-label="Live joint tracking overlay" role="img">
      <defs>
        <filter id="glow"><feGaussianBlur stdDeviation="2.8" result="coloredBlur" /><feMerge><feMergeNode in="coloredBlur" /><feMergeNode in="SourceGraphic" /></feMerge></filter>
      </defs>
      {pose}
    </svg>
  );
}

function MuscleMap() {
  return (
    <div className="muscle-map" aria-label="Muscle focus map">
      <div className="body-glow body-glow-a" />
      <div className="body-glow body-glow-b" />
      <svg viewBox="0 0 280 370" role="img" aria-label="Front body muscle focus diagram">
        <g fill="none" stroke="#67716d" strokeWidth="2.2" opacity=".72">
          <circle cx="140" cy="40" r="25" /><path d="M140 65v48 M104 85l36 28 36-28 M104 85l-13 81 24 57 M176 85l13 81-24 57 M128 113l-8 110 20 105 M152 113l8 110-20 105" />
        </g>
        <g fill="#b7f34a" opacity=".9"><path d="M108 91q16-13 28 2v35q-20 9-31-7z" /><path d="M172 91q-16-13-28 2v35q20 9 31-7z" /><path d="M115 143q25 12 50 0l-5 27q-20 10-40 0z" /></g>
        <g fill="#f0b95a" opacity=".94"><path d="M108 145q-12 4-17 23l18 36 14-35z" /><path d="M172 145q12 4 17 23l-18 36-14-35z" /></g>
        <g fill="#b7f34a" opacity=".78"><path d="M118 221l15 3-6 89-16-4z" /><path d="M162 221l-15 3 6 89 16-4z" /></g>
      </svg>
      <span className="muscle-label muscle-label-quad"><i />Quads</span>
      <span className="muscle-label muscle-label-glute"><i />Glutes</span>
      <span className="muscle-label muscle-label-core"><i />Core</span>
      <div className="muscle-map-legend"><span><i className="legend-dot lime-dot" />primary</span><span><i className="legend-dot amber-dot" />stabilizer</span></div>
    </div>
  );
}

function App() {
  const [selectedExercise, setSelectedExercise] = useState(0);
  const [isLive, setIsLive] = useState(false);
  const [isCameraOn, setIsCameraOn] = useState(false);
  const [cameraError, setCameraError] = useState("");
  const [phase, setPhase] = useState(0);
  const [activeNav, setActiveNav] = useState("Live analysis");
  const [mobileNav, setMobileNav] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [opencvReady, setOpencvReady] = useState(false);
  const [sessionStep, setSessionStep] = useState(0);
  const [sessionSeconds, setSessionSeconds] = useState(0);
  const [sessionRunning, setSessionRunning] = useState(false);
  const [transitionSeconds, setTransitionSeconds] = useState(0);
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [voiceStatus, setVoiceStatus] = useState<"correct" | "wrong" | "idle">("idle");
  const lastVoiceAt = useRef(0);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const currentExercise = exercises[selectedExercise];
  const activePlanStep = sessionPlan[sessionStep];
  const sessionProgress = Math.min(100, ((sessionStep + (isLive ? 0.18 : 0)) / sessionPlan.length) * 100);
  const secondsLeft = Math.max(0, BLOCK_SECONDS - sessionSeconds);
  const clockText = `${String(Math.floor(secondsLeft / 60)).padStart(2, "0")}:${String(secondsLeft % 60).padStart(2, "0")}`;
  const totalSessionText = `${String(Math.floor((sessionStep * BLOCK_SECONDS + sessionSeconds) / 60)).padStart(2, "0")}:${String((sessionStep * BLOCK_SECONDS + sessionSeconds) % 60).padStart(2, "0")}`;
  const isGood = isLive ? Math.sin(phase / 10) > -0.35 : true;
  const score = isLive ? Math.max(72, Math.min(98, Math.round(89 + Math.sin(phase / 9) * 8))) : 92;
  const repCount = isLive ? 7 + Math.floor(phase / 44) : 6;
  const kneeAngle = isLive ? Math.round(90 + Math.sin(phase / 9) * 7 + (isGood ? 0 : 8)) : 93;
  const hipAngle = isLive ? Math.round(78 + Math.sin(phase / 12) * 6) : 82;

  const jointMetrics: JointMetric[] = useMemo(() => [
    { label: "Left knee", value: `${kneeAngle}°`, detail: kneeAngle > 98 ? "Track knee outward" : "Within target range", status: kneeAngle > 98 ? "watch" : "good" },
    { label: "Right knee", value: `${Math.max(88, kneeAngle - 2)}°`, detail: "Within target range", status: "good" },
    { label: "Hip", value: `${hipAngle}°`, detail: hipAngle < 74 ? "Lift chest slightly" : "Great depth", status: hipAngle < 74 ? "watch" : "good" },
    { label: "Shoulder", value: isLive ? "96%" : "98%", detail: "Level and stable", status: "good" },
    { label: "Spine", value: isLive && !isGood ? "Watch" : "Good", detail: isLive && !isGood ? "Stack ribs over hips" : "Neutral alignment", status: isLive && !isGood ? "watch" : "good" },
  ], [hipAngle, isGood, isLive, kneeAngle]);

  const stopCamera = useCallback(() => {
    streamRef.current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
    if (videoRef.current) videoRef.current.srcObject = null;
    setIsCameraOn(false);
  }, []);

  const startCamera = useCallback(async () => {
    setCameraError("");
    if (!navigator.mediaDevices?.getUserMedia) {
      setCameraError("Camera access is not available in this browser. Demo mode is ready instead.");
      setIsLive(true);
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "user", width: { ideal: 1280 }, height: { ideal: 720 } }, audio: false });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      setIsCameraOn(true);
      setIsLive(true);
      toast.success("Camera connected — step back so your full body is in frame.");
    } catch {
      setCameraError("Camera permission was not granted. Demo mode is running with a simulated pose.");
      setIsLive(true);
      toast("Demo mode is ready", { description: "You can still explore the full coaching flow without a camera." });
    }
  }, []);

  useEffect(() => {
    const scriptId = "opencv-js";
    if (document.getElementById(scriptId)) return;
    const script = document.createElement("script");
    script.id = scriptId;
    script.async = true;
    script.src = "https://docs.opencv.org/4.x/opencv.js";
    script.onload = () => setOpencvReady(true);
    script.onerror = () => setOpencvReady(false);
    document.head.appendChild(script);
  }, []);

  useEffect(() => {
    if (!isLive) return;
    const timer = window.setInterval(() => setPhase((value) => value + 1), 300);
    return () => window.clearInterval(timer);
  }, [isLive]);

  useEffect(() => {
    if (!isLive || !voiceEnabled || typeof window === "undefined" || !("speechSynthesis" in window)) {
      if (!isLive && "speechSynthesis" in window) window.speechSynthesis.cancel();
      if (!isLive) setVoiceStatus("idle");
      return;
    }
    const now = Date.now();
    if (now - lastVoiceAt.current < 4200) return;
    lastVoiceAt.current = now;
    const correct = isGood;
    setVoiceStatus(correct ? "correct" : "wrong");
    const announcement = correct ? "Posture is correct." : "Posture is wrong. Open your left knee.";
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(announcement);
    utterance.rate = 0.96;
    utterance.pitch = correct ? 1.06 : 0.92;
    utterance.volume = 0.9;
    window.speechSynthesis.speak(utterance);
  }, [isGood, isLive, voiceEnabled]);

  useEffect(() => {
    if (!sessionRunning || transitionSeconds > 0) return;
    const timer = window.setInterval(() => {
      setSessionSeconds((value) => {
        if (value < BLOCK_SECONDS - 11) return value + 1;
        setTransitionSeconds(10);
        if ("speechSynthesis" in window) {
          window.speechSynthesis.cancel();
          const announcement = new SpeechSynthesisUtterance("Next exercise in 10 seconds.");
          announcement.rate = 0.95;
          announcement.pitch = 1;
          window.speechSynthesis.speak(announcement);
        }
        return value;
      });
    }, 1000);
    return () => window.clearInterval(timer);
  }, [sessionRunning, sessionStep, transitionSeconds]);

  useEffect(() => {
    if (!sessionRunning || transitionSeconds <= 0) return;
    const timer = window.setInterval(() => {
      setTransitionSeconds((value) => {
        if (value <= 1) {
          const nextStep = (sessionStep + 1) % sessionPlan.length;
          setSessionStep(nextStep);
          setSelectedExercise(sessionPlan[nextStep].exercise);
          setSessionSeconds(0);
          toast.success(`${sessionPlan[nextStep].name} is now active`, { description: `${sessionPlan[nextStep].minute} · Focus: ${sessionPlan[nextStep].focus}` });
          if ("speechSynthesis" in window) {
            window.speechSynthesis.cancel();
            const announcement = new SpeechSynthesisUtterance(`${sessionPlan[nextStep].name}. Posture ready.`);
            announcement.rate = 0.95;
            window.speechSynthesis.speak(announcement);
          }
          return 0;
        }
        if (value <= 5 && "speechSynthesis" in window) {
          window.speechSynthesis.cancel();
          const announcement = new SpeechSynthesisUtterance(String(value - 1));
          announcement.rate = 1;
          window.speechSynthesis.speak(announcement);
        }
        return value - 1;
      });
    }, 1000);
    return () => window.clearInterval(timer);
  }, [sessionRunning, sessionStep, transitionSeconds]);

  useEffect(() => () => stopCamera(), [stopCamera]);

  const handleNav = (label: string) => {
    setActiveNav(label);
    setMobileNav(false);
    if (label !== "Live analysis") {
      toast(`${label} is on the roadmap`, { description: "The live analysis workspace stays available here while we build the next view." });
    }
  };

  const handleStart = () => {
    if (isLive) {
      setIsLive(false);
      setSessionRunning(false);
      setTransitionSeconds(0);
      stopCamera();
      toast("Session paused", { description: "Your live camera has been safely disconnected." });
      return;
    }
    setSessionRunning(true);
    startCamera();
  };

  const completePosture = () => {
    const nextStep = (sessionStep + 1) % sessionPlan.length;
    setSessionStep(nextStep);
    setSelectedExercise(sessionPlan[nextStep].exercise);
    setIsLive(false);
    setSessionRunning(false);
    setSessionSeconds(0);
    setTransitionSeconds(0);
    stopCamera();
    toast.success(`${sessionPlan[nextStep].name} is next`, { description: `${sessionPlan[nextStep].minute} · ${sessionPlan[nextStep].focus}` });
  };

  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileNav ? "sidebar-open" : ""}`}>
        <div className="brand-lockup">
          <div className="brand-mark"><Activity size={21} strokeWidth={2.4} /></div>
          <div><div className="brand-name">form<span>lab</span></div><div className="brand-subtitle">movement intelligence</div></div>
          <button className="sidebar-close" onClick={() => setMobileNav(false)} aria-label="Close navigation"><X size={18} /></button>
        </div>
        <div className="workspace-select"><div className="workspace-avatar">JM</div><div className="workspace-copy"><span>Jordan’s home gym</span><small>Personal workspace</small></div><ChevronDown size={15} /></div>
        <div className="nav-label">Workspace</div>
        <nav className="primary-nav" aria-label="Primary navigation">
          {navItems.map((item) => {
            const Icon = item.icon;
            return <button key={item.label} className={`nav-item ${activeNav === item.label ? "nav-item-active" : ""}`} onClick={() => handleNav(item.label)}><Icon size={18} strokeWidth={1.9} /><span>{item.label}</span>{item.badge && <span className="nav-badge">{item.badge}</span>}</button>;
          })}
        </nav>
        <div className="nav-label nav-label-lower">Tools</div>
        <nav className="secondary-nav">
          <button className="nav-item" onClick={() => toast("Your movement profile is looking strong", { description: "Consistency is the fastest path to cleaner reps." })}><Target size={18} /><span>Progress</span></button>
          <button className="nav-item" onClick={() => toast("Form guide opened", { description: "Every cue in the live view is based on joint alignment." })}><BookOpen size={18} /><span>Form guide</span></button>
        </nav>
        <div className="sidebar-bottom">
          <div className="privacy-card"><div className="privacy-icon"><LockKeyhole size={16} /></div><div><strong>Private by design</strong><p>Video stays on your device.</p></div></div>
          <button className="settings-link" onClick={() => toast("Settings are saved locally", { description: "No account or paid plan required." })}><Settings2 size={17} /><span>Settings</span></button>
          <div className="version">formlab v1.0 · free forever</div>
        </div>
      </aside>

      <main className="main-content">
        <header className="topbar">
          <button className="mobile-menu" onClick={() => setMobileNav(true)} aria-label="Open navigation"><Menu size={20} /></button>
          <div className="topbar-context"><span className="crumb-muted">Workspace</span><span className="crumb-slash">/</span><strong>Live analysis</strong></div>
          <div className="topbar-actions"><div className="system-status"><span className="pulse-dot" />{opencvReady ? "CV engine ready" : "CV engine loading"}</div><button className="icon-button" aria-label="Notifications" onClick={() => toast("No new notifications", { description: "You’re all caught up." })}><Bell size={18} /><span className="notification-dot" /></button><div className="user-avatar">JM</div></div>
        </header>

        <div className="content-wrap">
          <section className="page-intro">
            <div><p className="eyebrow lime-text"><span className="eyebrow-line" />TRAIN SMARTER AT HOME</p><h1>Your form, <em>decoded.</em></h1><p className="page-subtitle">Real-time movement feedback for stronger, safer reps.</p></div>
            <div className="intro-actions"><StatusPill tone="slate"><ShieldCheck size={14} /> privacy-first</StatusPill><button className="help-button" onClick={() => setShowDetails((value) => !value)}><CircleHelp size={16} />How it works</button></div>
          </section>

          {showDetails && <div className="how-it-works"><div className="how-step"><span>01</span><strong>Choose an exercise</strong><p>Start with a movement that matches your setup.</p></div><div className="how-step"><span>02</span><strong>Step into frame</strong><p>Keep your full body visible, then start the session.</p></div><div className="how-step"><span>03</span><strong>Act on the cue</strong><p>Use live joint angles to clean up every rep.</p></div></div>}

          <section className="control-strip panel">
            <div className="exercise-picker"><div className="exercise-icon"><Dumbbell size={18} /></div><div className="picker-copy"><label htmlFor="exercise-select">EXERCISE</label><select id="exercise-select" value={selectedExercise} onChange={(event) => { setSelectedExercise(Number(event.target.value)); setIsLive(false); stopCamera(); }}><option value={0}>Bodyweight squat</option><option value={1}>Push-up</option><option value={2}>Reverse lunge</option><option value={3}>Plank</option><option value={4}>Jumping jack</option><option value={5}>Standing shoulder press</option><option value={6}>Glute bridge</option><option value={7}>Mountain climber</option></select></div><ChevronDown className="select-chevron" size={17} /></div>
            <div className="exercise-context"><span className="context-tag">{currentExercise.category}</span><span className="context-divider" /><span className="context-detail">Target: {currentExercise.target}</span><span className="context-joints">{currentExercise.joints}</span></div>
            <button className={`start-button ${isLive ? "start-button-live" : ""}`} onClick={handleStart}>{isLive ? <><CirclePause size={17} />Pause session</> : <><Play size={17} fill="currentColor" />Start live session</>}<span className="button-shortcut">{isLive ? "ESC" : "⌘ ↵"}</span></button>
          </section>

          <section className="session-plan panel"><div className="session-plan-header"><div><p className="eyebrow lime-text"><span className="eyebrow-line" />12-MINUTE FLOW</p><h3>Two minutes. Then switch.</h3><p>Each posture runs for 2 minutes, followed by a spoken 10-second transition countdown.</p></div><div className={`plan-clock ${transitionSeconds > 0 ? "plan-clock-transition" : ""}`}><strong>{transitionSeconds > 0 ? `00:${String(transitionSeconds).padStart(2, "0")}` : sessionRunning ? clockText : "02:00"}</strong><small>{transitionSeconds > 0 ? "switching next" : sessionRunning ? "current block" : "per posture"}</small></div><div className="plan-progress"><strong>{sessionStep + 1}<span>/6</span></strong><small>postures</small></div></div><div className="plan-track"><span style={{ width: `${sessionProgress}%` }} /></div><div className="plan-steps">{sessionPlan.map((step, index) => <button key={step.name} className={`plan-step ${index === sessionStep ? "plan-step-active" : ""} ${index < sessionStep ? "plan-step-complete" : ""}`} onClick={() => { setSessionStep(index); setSelectedExercise(step.exercise); setIsLive(false); setSessionRunning(false); setSessionSeconds(0); setTransitionSeconds(0); stopCamera(); }}><span className="plan-step-number">{index < sessionStep ? "✓" : `0${index + 1}`}</span><span className="plan-step-copy"><strong>{step.name}</strong><small>{step.minute} · {step.focus}</small></span></button>)}</div></section>

          <section className="analysis-grid">
            <div className="camera-panel panel">
              <div className="panel-header"><div><p className="eyebrow">LIVE CAMERA</p><h2>{isLive ? "You’re in the zone" : "Ready when you are"}</h2></div><div className="camera-header-actions">{isLive && <StatusPill tone={isGood ? "lime" : "amber"}><span className="status-live-dot" />{isGood ? "Good form" : "Adjust form"}</StatusPill>}<button className={`voice-toggle ${voiceEnabled ? "voice-toggle-on" : ""}`} onClick={() => { setVoiceEnabled((value) => !value); if (voiceEnabled && "speechSynthesis" in window) window.speechSynthesis.cancel(); toast(voiceEnabled ? "Voice coaching off" : "Voice coaching on", { description: voiceEnabled ? "Visual feedback will continue." : "You’ll hear correct/wrong posture alerts." }); }} aria-pressed={voiceEnabled}><Activity size={14} />{voiceEnabled ? "Voice on" : "Voice off"}</button><button className="more-button" onClick={() => toast("Camera setup", { description: "Place your camera 2–3 m away at hip height for best tracking." })} aria-label="Camera tips"><MoreHorizontal size={19} /></button></div></div>
              <div className={`camera-stage ${isLive ? "camera-stage-live" : ""}`}>
                <video ref={videoRef} className={`camera-video ${isCameraOn ? "camera-video-visible" : ""}`} muted playsInline />
                <div className="stage-grid" />
                {!isCameraOn && <div className="preview-action-tag"><span className="preview-action-kicker">FORM PREVIEW</span><strong>{currentExercise.name}</strong><small>Follow the highlighted joints</small></div>}
                <PostureOverlay phase={phase} isGood={isGood} exerciseIndex={selectedExercise} />
                {!isLive && <div className="camera-empty"><div className="camera-empty-icon"><Video size={22} /></div><strong>Camera preview starts here</strong><span>We never upload or store your video.</span><button onClick={startCamera}><Camera size={16} />Enable camera</button></div>}
                {isLive && <><div className="tracking-tag"><span className="tracking-icon"><ScanLine size={13} /></span>tracking 17 joints</div><div className={`stage-feedback ${isGood ? "stage-feedback-good" : "stage-feedback-watch"}`}><span className="feedback-dot" />{isGood ? "Posture is correct" : "Posture is wrong"}</div><JointChip joint="shoulder" x={48} y={22} /><JointChip joint="hip" x={44} y={42} /><JointChip joint="knee" x={30} y={59} active={!isGood} /></>}
                <div className="camera-corner camera-corner-tl" /><div className="camera-corner camera-corner-tr" /><div className="camera-corner camera-corner-bl" /><div className="camera-corner camera-corner-br" />
              </div>
              {cameraError && <div className="camera-note"><Info size={15} />{cameraError}</div>}
              <div className="camera-footer"><div className="camera-meta"><span className="meta-dot" />{isLive ? "Tracking active" : "Camera off"}<span className="meta-divider" />{opencvReady ? "OpenCV.js ready" : "Loading OpenCV.js"}{isLive && sessionRunning && <><span className="meta-divider" /><span className="timer-status">Session {totalSessionText} / 12:00</span></>}{isLive && voiceEnabled && <><span className="meta-divider" /><span className={`voice-status ${voiceStatus}`}>{voiceStatus === "correct" ? "Voice: correct" : voiceStatus === "wrong" ? "Voice: wrong" : "Voice ready"}</span></>}</div><div className="camera-footer-actions"><button className="ghost-button" onClick={() => { setPhase(0); setSessionSeconds(0); setTransitionSeconds(0); toast("Analysis reset"); }}><RotateCcw size={15} />Reset</button><button className="ghost-button" onClick={() => toast("Tip: use a side angle for squats and lunges", { description: "A full-body frame gives the clearest joint readout." })}><Lightbulb size={15} />Coach tip</button>{isLive && <button className="complete-button" onClick={completePosture}><BadgeCheck size={14} />Complete posture</button>}</div></div>
            </div>

            <div className="side-stack">
              <div className={`score-panel panel ${isGood ? "score-panel-good" : "score-panel-watch"}`}><div className="score-topline"><div><p className="eyebrow">FORM SCORE</p><div className="score-value">{score}<span>/100</span></div></div><div className="score-ring" style={{ "--score": `${score * 3.6}deg` } as React.CSSProperties}><div><span>{score}</span><small>score</small></div></div></div><div className="score-bar"><span style={{ width: `${score}%` }} /></div><div className="score-bottom"><span><TrendingUp size={14} />+8% vs last session</span><span className="score-state">{isGood ? "Keep it up" : "Small adjustment"}</span></div></div>

              <div className="joint-panel panel"><div className="panel-header compact"><div><p className="eyebrow">JOINT CHECK</p><h3>Alignment at a glance</h3></div><button className="small-link" onClick={() => setShowDetails(true)}>View guide <ArrowUpRight size={14} /></button></div><div className="joint-list">{jointMetrics.map((metric) => <div className="joint-row" key={metric.label}><div className={`joint-status ${metric.status}`}><span /></div><div className="joint-info"><strong>{metric.label}</strong><small>{metric.detail}</small></div><b>{metric.value}</b><ArrowDownRight size={15} className={metric.status === "watch" ? "joint-arrow-watch" : "joint-arrow-good"} /></div>)}</div><div className="joint-footnote"><Gauge size={15} /><span>Angles are estimated from your live landmarks.</span></div></div>
            </div>
          </section>

          <section className="lower-grid">
            <div className="cue-panel panel"><div className="panel-header compact"><div><p className="eyebrow">NEXT BEST CUE</p><h3>One adjustment at a time.</h3></div><div className="cue-spark"><Sparkles size={17} /></div></div><div className="cue-content"><div className="cue-number">{isGood ? "01" : "02"}</div><div><h4>{isGood ? currentExercise.cue : "Drive your left knee outward as you descend."}</h4><p>{isGood ? "Your lower body is moving with control. Keep this rhythm for your next rep." : "This keeps your knee stacked over your foot and protects the joint."}</p></div></div><div className="cue-footer"><span><Zap size={14} />Focus cue</span><button onClick={() => toast("Cue pinned", { description: "We’ll keep this cue visible during the next session." })}>Pin cue <ArrowUpRight size={14} /></button></div></div>
            <div className="muscle-panel panel"><div className="panel-header compact"><div><p className="eyebrow">MUSCLE MAP</p><h3>What’s working</h3></div><span className="muscle-focus">{currentExercise.muscle}</span></div><MuscleMap /></div>
            <div className="session-panel panel"><div className="panel-header compact"><div><p className="eyebrow">TODAY’S SESSION</p><h3>Small wins compound.</h3></div><button className="more-button" onClick={() => toast("Session actions", { description: "Your session summary is saved locally on this device." })} aria-label="Session actions"><MoreHorizontal size={19} /></button></div><div className="session-stats"><div><strong>{repCount}</strong><span>reps</span></div><div><strong>03:42</strong><span>duration</span></div><div><strong>92%</strong><span>consistency</span></div></div><div className="session-chart"><div className="chart-labels"><span>form score</span><strong>92 <small>avg.</small></strong></div><svg viewBox="0 0 320 76" preserveAspectRatio="none" aria-label="Form score trend"><path d="M0 59 C22 55 26 42 47 49 S74 61 91 44 S117 30 133 40 S161 57 180 34 S207 25 220 35 S250 45 270 25 S297 20 320 12" fill="none" stroke="#b7f34a" strokeWidth="3" /><path d="M0 59 C22 55 26 42 47 49 S74 61 91 44 S117 30 133 40 S161 57 180 34 S207 25 220 35 S250 45 270 25 S297 20 320 12 V76 H0Z" fill="url(#chartFill)" opacity=".24" /><defs><linearGradient id="chartFill" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="#b7f34a" /><stop offset="1" stopColor="#b7f34a" stopOpacity="0" /></linearGradient></defs></svg><div className="chart-axis"><span>10:00</span><span>10:02</span><span>10:04</span></div></div><button className="full-width-button" onClick={() => handleNav("Session history")}>Open session history <ArrowUpRight size={15} /></button></div>
          </section>

          <section className="report-section"><div className="report-heading"><div><p className="eyebrow lime-text"><span className="eyebrow-line" />YOUR OVERVIEW REPORT</p><h2>Train with context.</h2><p>Understand what each posture builds, what needs work, and how to fuel your body.</p></div><StatusPill tone="slate"><ShieldCheck size={14} /> local report</StatusPill></div><div className="report-grid"><div className="report-card panel benefits-card"><div className="report-card-title"><div className="report-icon"><Sparkles size={16} /></div><div><p className="eyebrow">CURRENT POSTURE</p><h3>{currentExercise.name}</h3></div></div><p className="report-lead">{currentExercise.benefits}</p><div className="report-tags"><span>{currentExercise.category}</span><span>{currentExercise.muscle}</span></div><div className="report-list"><div><BadgeCheck size={15} /><span><strong>Primary target</strong>{currentExercise.joints}</span></div><div><Target size={15} /><span><strong>Form target</strong>{currentExercise.target}</span></div></div></div><div className="report-card panel mistakes-card"><div className="report-card-title"><div className="report-icon report-icon-amber"><Activity size={16} /></div><div><p className="eyebrow">SESSION QUALITY</p><h3>What to improve</h3></div></div><div className="quality-score"><strong>{isGood ? "92" : "78"}</strong><span>/100 quality</span></div><div className="quality-rows"><div><span>Clean reps</span><strong>{isGood ? "18" : "14"}</strong></div><div><span>Form mistakes</span><strong className="text-amber">{isGood ? "2" : "6"}</strong></div><div><span>Missed corrections</span><strong>{isGood ? "1" : "3"}</strong></div></div><p className="report-note"><Info size={14} />{isGood ? "Good consistency. Keep responding to the voice cue." : "Slow down and respond to the highlighted joint correction."}</p></div><div className="report-card panel diet-card"><div className="report-card-title"><div className="report-icon report-icon-blue"><Dumbbell size={16} /></div><div><p className="eyebrow">BODY MAINTENANCE</p><h3>Simple dietary plan</h3></div></div><p className="diet-disclaimer">A flexible starting guide—not medical advice. Adjust for your needs.</p><div className="diet-list">{dietaryPlan.map((item) => <div className="diet-row" key={item.meal}><div className="diet-time">{item.meal}<small>{item.timing}</small></div><p>{item.suggestion}</p><span>{item.purpose}</span></div>)}</div></div></div></section>

          <footer className="app-footer"><span><ShieldCheck size={14} />No sign-up. No paywall. No uploads.</span><span>Built for everyday movement.</span></footer>
        </div>
      </main>
    </div>
  );
}

export default App;
